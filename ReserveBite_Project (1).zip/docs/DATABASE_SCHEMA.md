# Database schema overview

- `customers`: guest contact information.
- `dining_tables`: table number, seating capacity and floor status.
- `reservations`: guest/table references, start/end time, party size and status.
- `menu_categories` and `menu_items`: normalized menu categories and dishes.
- `staff`: staff role and shift.
- `dining_orders` and `order_items`: order header and line items.
- `ingredients` and `recipes`: inventory quantities and dish-to-ingredient mappings.
- `coupons`: percentage/flat discounts and minimum subtotal.
- `bills` and `payments`: bill calculations and payment records.
- `waitlist`: walk-in queue.
- `feedback`: rating/comments, optionally linked to an order.
- `audit_log`: recorded actions.
- `restaurant_settings`: key/value settings.

Primary and foreign keys maintain record relationships. DECIMAL columns are used for prices and fractional stock. Overlapping reservation prevention must be enforced in a backend transaction, especially for concurrent requests.
