# ReserveBite feature list

- Dashboard with daily reservation, table, order and revenue summaries.
- Reservations with best-fit table allocation, time overlap checks, seating, completion and cancellation.
- Walk-in waiting list.
- Table capacity/status management.
- Menu search, categories, price editing and availability.
- Multi-item orders and kitchen workflow.
- Billing with coupon discounts, configurable GST/service charge and simulated Cash/UPI/Card payments.
- Ingredient inventory, recipe links and low-stock alerts.
- Coupon management.
- Guest feedback and ratings.
- Staff directory and Manager/Waiter/Chef UI role demonstration.
- Revenue and popular-dish reports, peak reservation hours, audit log.
- JSON backup/restore and CSV audit export.
- Responsive desktop/mobile layout.

Demo limitations: browser localStorage is not shared between devices; role switching is not secure authentication; payment processing is simulated.
