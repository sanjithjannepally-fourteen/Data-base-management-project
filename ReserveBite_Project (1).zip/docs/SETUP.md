# Setup instructions

1. Extract `ReserveBite_Project.zip`.
2. Open `public/index.html` in a modern browser to use the demo.
3. For MySQL, install MySQL 8.0+.
4. Run `mysql -u root -p < database/reservebite_schema.sql`, or open the SQL file in MySQL Workbench and execute it.
5. Verify with `USE reservebite; SHOW TABLES;`.

The browser app stores demo data in localStorage and does not directly connect to MySQL. Add a server-side API with validated endpoints and parameterized SQL to connect the interface to the database. Implement authentication and authorization on the server before production use.
