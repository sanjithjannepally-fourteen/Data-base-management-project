# ReserveBite
Restaurant reservations and food-service management project.

## Contents
- `public/index.html`: responsive browser-based ReserveBite app.
- `database/reservebite_schema.sql`: MySQL 8+ schema with tables, constraints, indexes, and starter records.
- `docs/SETUP.md`: run and database setup instructions.
- `docs/DATABASE_SCHEMA.md`: relationships and schema overview.
- `docs/FEATURES.md`: feature inventory.

## Run the app
Extract the ZIP and open `public/index.html` in Chrome, Edge, or Firefox. The demo saves its data in the browser's local storage.

## Import MySQL schema
Install MySQL 8+, then run:
```bash
mysql -u root -p < database/reservebite_schema.sql
```
Or open the SQL file in MySQL Workbench and execute it.

## Important
The standalone HTML app currently uses browser localStorage. The supplied MySQL schema is included but is not connected to the frontend. To connect them, add a backend API (such as Node.js/Express or Python/Flask); do not expose database credentials in browser code. Payment processing and authentication are demo-only/not live.
